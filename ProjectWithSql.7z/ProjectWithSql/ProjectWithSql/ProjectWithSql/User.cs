﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectWithSql
{

    public class User
    {
        string id, pw;
        private string[] borrowlist;
        private ArrayList history;

        public User(string id, string pw)
        {
            this.id = id;
            this.pw = pw;
            borrowlist = getBorrowList();
            history = getHistory();
        }

        public User(string id)
        {
            this.id = id;
            pw = getUserPW();
            borrowlist = getBorrowList();
            history = getHistory();
        }

        DatabaseConnection connection = new DatabaseConnection();

        public string getUserLvl()
        {
            string holder = "";
            if (connection.doesExist("UserList", id, "ID"))
            {
                holder = connection.getTable("UserList", id, "ID").Rows[0][2].ToString();
            }
            return holder;
        }

        public string getUserID()
        {
            string holder = ""; //initialize null for the first time for unfound userid
            if (connection.doesExist("UserList", id, "ID"))
            {
                holder = connection.getTable("UserList", id, "ID").Rows[0][0].ToString();
            }
            return holder;
        }

        public int getUserBookNum()
        {
            int holder = 0; //initialize null for the first time unfound userid
            if (connection.doesExist("UserList", id, "ID"))
            {
                holder = Convert.ToInt32(connection.getTable("UserList", id, "ID").Rows[0][3]);
            }
            return holder;
        }

        public string getUserPW()
        {
            string holder = ""; //initialize null incase it does not exists
            if (connection.doesExist("UserList", id, "ID"))
            {
                holder = connection.getTable("UserList", id, "ID").Rows[0][1].ToString();
            }
            return holder;
        }

        public string getUserSecretQ()
        {
            string holder = ""; //initialize null for the first time for unfound userid
            if (connection.doesExist("UserList", id, "ID"))
            {
                holder = connection.getTable("UserList", id, "ID").Rows[0][9].ToString();
            }
            return holder;
        }



        //all the sets are handled by id except setID and setLvl do not exist for security purposes

        public void setUserPW(string value)
        {
            if (connection.doesExist("UserList", id, "ID"))
            {
                connection.Update("UserList", value, "PW", id);
            }

        }

        public void setUserBookNum(int value)
        {
            if (connection.doesExist("UserList", id, "ID"))//if the user exists
            {
                connection.Update("UserList", value.ToString(), "BookNumber", id);
            }

        }
        public void setUserSecretQ(string answer)
        {
            if (connection.doesExist("UserList", id, "ID"))//if the user exists
            {
                connection.Update("UserList", answer, "SecretQ", id);
            }
        }

        //user actions

        //questioning user's rights to borrow
        public bool canborrowbook()
        {
            if (getUserBookNum() < 5) // user can get a book
            {
                return true;
            }
            else
                return false;

        }

        //the book to be borrowed, and its quantity checked on borrow request button, and quantity of the book reduced in the booklistview form
        public void borrowbook(string bookid)
        {
            getBorrowList();
            borrowlist[getindex("0")] = bookid;    //add the specific book to user's borrow list
            setBorrowList();
            Book book = new Book(bookid);
            connection.Update("BookList", (book.getQuantity() - 1).ToString(), "Quantity", bookid);
            setUserBookNum(getUserBookNum() + 1);  // increment userbook number by one
            addToHistory(book, DateTime.Now, "Borrow");
        }

        //borrowed book's  id  checked on 'deliver request' button on BookListView form and quantity of the book increased there
        public void deliverbook(string bookid)
        {
            getBorrowList();
            setUserBookNum(getUserBookNum() - 1); // decrement userbook number by one
            if (getindex(bookid) != -1)//if book is found in the borrowlist
            {
                Book book = new Book(bookid);
                borrowlist[getindex(bookid)] = "0"; //set that index to 0 : represents there is no book in that field         !!NOTE: NO ANY BOOK CAN HAVE ID '0' IT IS RESERVED
                setBorrowList();  //update borrowlist
                connection.Update("BookList", (book.getQuantity() + 1).ToString(), "Quantity", bookid);
                addToHistory(book, DateTime.Now, "Deliver");
            }

        }


        //writes back the borrowlist to database
        public void setBorrowList() //writing changed borrowlist to db back
        {
            connection.Update("UserList", borrowlist[0], "Book0", id);
            connection.Update("UserList", borrowlist[1], "Book1", id);
            connection.Update("UserList", borrowlist[2], "Book2", id);
            connection.Update("UserList", borrowlist[3], "Book3", id);
            connection.Update("UserList", borrowlist[4], "Book4", id);

        }


        //retrieves data from the db adds it to borrowlist and returns the entire borrowlist
        public string[] getBorrowList()
        {
            string[] borrowlist = new string[5];
            borrowlist[0] = connection.getTable("UserList", id, "ID").Rows[0][4].ToString();
            borrowlist[1] = connection.getTable("UserList", id, "ID").Rows[0][5].ToString();
            borrowlist[2] = connection.getTable("UserList", id, "ID").Rows[0][6].ToString();
            borrowlist[3] = connection.getTable("UserList", id, "ID").Rows[0][7].ToString();
            borrowlist[4] = connection.getTable("UserList", id, "ID").Rows[0][8].ToString();
            return borrowlist;
        }


        //returns the found bookid's index in the array
        public int getindex(string bookid)
        {
            int holder = -1;
            for (int i = 0; i < borrowlist.Length; i++)
            {
                if (borrowlist[i].ToString().Equals(bookid))
                {
                    holder = i;
                    break;
                }
            }
            return holder;
        }

        public void addToHistory(Book book, DateTime now, string action)
        {
            string hist = action + " : " + book.getBookName() + " " + book.getAuthor() + " on " + now.ToShortDateString()+"-";
            history.Add(hist);
            appendHistory(hist);
        }

        public ArrayList getHistory()
        {
            ArrayList history = new ArrayList();
            string wholehistory = connection.getTable("UserList", id, "ID").Rows[0][10].ToString();   //all the history of an user
            string[] words = wholehistory.Split('-');  // Split string on "-" (this will separate all the history).
            foreach (string historypart in words)
            {
                history.Add(historypart);
            }
           return history;  
        }

        void appendHistory(string appendhistory) //sets the changed history list back to database
        {
            string wholehistory = connection.getTable("UserList", id, "ID").Rows[0][10].ToString();   //all the history of an user
            wholehistory += appendhistory;
            connection.Update("UserList", wholehistory, "History", id);
        }

    }
}
