﻿using System;
using System.Data;
using System.IO;
using System.Windows.Forms;

namespace ProjectWithSql
{
    public partial class BookListView : Form
    {
        string entrylevel; 

        string id, pw;
        public BookListView(string entrylevel) //for showing booklist without any login, no any feautures only view & search
        {
            InitializeComponent();
            this.entrylevel = entrylevel;
        }

        public BookListView(string id, string pw)//showing booklist for user, enabling borrow-deliver feautures
        {
            InitializeComponent();
            this.id = id;
            this.pw = pw;
            User user = new User(id, pw);
            if (user.getUserLvl().Equals("0"))
            {
                entrylevel = "user";
            }
            else
            {
                entrylevel = "admin";
            }
        }

        private void Books_Load(object sender, EventArgs e)
        {
            button10.Hide();
            if (entrylevel!="admin")
            {
                button3.Hide(); //hiding unavaible buttons and labels for user and guest enterance
                button2.Hide();
                button5.Hide();
                
                
                textBox4.Hide();
                label4.Hide();
            }
            if (entrylevel.Equals("guest"))
            {
                groupBox4.Hide();
                button10.Show();
                textBox3.Hide();
                label3.Hide();
            }
             dataGridView1.DataSource = connection.getTable("BookList");
            
        }

        DatabaseConnection connection = new DatabaseConnection();

        //filling the datagridview with the whole database for representation of entire booklist
        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = connection.getTable("BookList");
        }

        //add button
        private void button2_Click(object sender, EventArgs e)
        {
            /* if (textBox1.Text.Length == 0 && textBox2.Text.Length == 0 && textBox3.Text.Length == 0)
             {
                 MessageBox.Show("You have to enter book name, author and book ID to add a book!");
             }
             else if (textBox3.Text.Length > 0 && textBox2.Text.Length < 0 && textBox1.Text.Length < 0)//id is a must
             {


                     MessageBox.Show("You have to enter book name, author and book ID to add a book!");

                 else
                 {
                     
                 }

             }
             else
                 MessageBox.Show("You have to enter a book ID!");*/

            if (textBox3.Text.Length > 0 && textBox2.Text.Length > 0 && textBox1.Text.Length > 0) //when all fields are filled
            {
                if (textBox3.Text.Equals("0") && Convert.ToInt32(textBox3.Text) < 0)  //handling a system-requirement. ID 0 makes no sense on numeration and it is represented for no book borrow for user's borrowlist
                {
                    MessageBox.Show("The ID '0' is reserved. No book can have negative ID number. Please give another ID!");
                }
                //if that id is already in the booklist, show an error
                else if (connection.doesExist("BookList", textBox3.Text, "ID"))
                {
                    MessageBox.Show("This book ID has already exist. If you want to change it please user update button!");
                }
                //given quantity cannot be negative, or left blank
                else if (textBox4.Text.Length > 0 && Convert.ToInt32(textBox4.Text) > 0)
                {
                    connection.inserttoDatabase("BookList", textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text);
                    MessageBox.Show("Added Succesfuly! Please Refresh to see new list");

                }
                else
                    MessageBox.Show("Quantity cannot be negative!");
            }
            else
                MessageBox.Show("Cannot add the book to booklist! None of the fields can be left blank!");
            
        }
                
            
            

        

        //remove button
        private void button3_Click(object sender, EventArgs e)
        {
            if (connection.doesExist("BookList", textBox3.Text, "ID")) // if the entered id row exists
            {
                connection.deletefromDatabase("BookList", textBox3.Text);
                MessageBox.Show("Deletion is succesful. Please refresh!");
                LogWrite("removed", id, textBox3.Text);
            }
            else
                MessageBox.Show("There is no such record to delete!");

        }

        //search msg pop up
        private void button4_Click(object sender, EventArgs e)
        {
            Book book = new Book(textBox1.Text, textBox2.Text);
            if (textBox1.Text.Length == 0 && textBox2.Text.Length != 0) //checking by author
            {
                if (book.getAuthor().Equals(""))

                    MessageBox.Show("Not Found!");

                else
                    MessageBox.Show(book.getAuthor() + " has found in the list!");
            }

            else if (textBox1.Text.Length != 0 && textBox2.Text.Length == 0) //checking by bookname
            {
                if (book.getBookName().Equals(""))

                    MessageBox.Show("Not Found!");

                else
                    MessageBox.Show(book.getBookName() + " has found in the list!");

            }

            else if (textBox1.Text.Length != 0 && textBox2.Text.Length != 0) //checking for both fields
            {
                if (connection.doesExist("BookList", textBox1.Text, "BookName") == true && connection.doesExist("BookList", textBox2.Text, "Author") == true)  //controlling the given fields exist in db
                {
                    //checking both fields are corresponding to each other, or two different values in the db
                    if (connection.getTable("BookList", textBox1.Text, "BookName").Rows[0][0].ToString().Equals(connection.getTable("BookList", textBox2.Text, "Author").Rows[0][0].ToString()))
                        MessageBox.Show(book.getBookName() + " " + book.getAuthor() + " has found in the list !");
                    else
                        MessageBox.Show("There is no matching!");
                }
                else
                    MessageBox.Show("One of the fields has not found!");
            }

            else
                MessageBox.Show("Please enter a value to search!");


        }

        //update button
        private void button5_Click(object sender, EventArgs e)
        {
            Book book = new Book(textBox1.Text, textBox2.Text, textBox3.Text);

            //when no id is given, warn user
            if (textBox3.Text.Length == 0)
            {
                MessageBox.Show("Please enter id of the row you wish to update!");
            }
            else
            {   // if the given book actualy exists in the db
                if (connection.doesExist("BookList", textBox3.Text, "ID"))
                {
                    if (textBox1.Text.Length == 0 && textBox2.Text.Length == 0 && textBox4.Text.Length == 0)
                    {
                        MessageBox.Show("Please enter a value to update!");
                    }
                    else //null controls are handled in set Methods
                    {
                        if (textBox4.Text.Length > 0)
                        {
                            book.setQuantity(Convert.ToInt32(textBox4.Text));
                        }

                        book.setAuthor(textBox2.Text);
                        book.setBookName(textBox1.Text);
                        MessageBox.Show("Record update is successful. Please refresh to see new table!");
                        LogWrite("updated", id, book.getID());
                    }
                }
                else
                    MessageBox.Show("Given book does not exists in booklist!");
            }
            
        }

        //back button
        
        private void button6_Click(object sender, EventArgs e)
        {
            WelcomePage wp = new WelcomePage();
            this.Close();
            wp.Show();
        }

        //deliver request button
        public void button8_Click(object sender, EventArgs e)
        {
            User user = new User(id, pw);
            
            
            if (textBox3.Text.Length > 0 && user.getindex(textBox3.Text)!=-1) //by id
            {
                if (connection.doesExist("BookList", textBox3.Text, "ID"))
                {
                    Book book = new Book(textBox3.Text);
                    user.deliverbook(textBox3.Text); //complete the action
                    MessageBox.Show("You have successfully delivered the book :" + book.getBookName());
                }
                else
                {
                    MessageBox.Show("Entered book's id cannot be 0!");
                }
            }
            else
            {
                
               if(textBox3.Text.Length<0)
                MessageBox.Show("You have to enter a book's ID in order to deliver it!");
               else
                {
                    if (!connection.doesExist("BookList", textBox3.Text, "ID"))
                    {
                        MessageBox.Show("This book does not belong to the library!");
                    }
                    else
                    MessageBox.Show("You do not have that book to deliver!");
                }
                  
            }
            
        }

        //go to user account view page
        
        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            User user = new User(id, pw);
            UserAccountView ua = new UserAccountView(id,pw,user.getBorrowList());
            ua.Show();
        }

        //borrow request button
        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox3.Text.Length>0 && connection.doesExist("BookList", textBox3.Text, "ID")) // if selected book exists in db 
            {
                User user = new User(id, pw);
                Book book = new Book(textBox3.Text);
                if (user.canborrowbook() && book.getQuantity() > 0)
                {
                    user.borrowbook(textBox3.Text); //complete the action
                    MessageBox.Show("You have borrowed the book : " + book.getBookName());
                }


                else  //except the inner if condition there are different warn msgs.
                {
                    if (book.getQuantity() == 0)
                    {
                        MessageBox.Show("This book is currently unavaible!");
                    }
                    else
                    {
                        MessageBox.Show("You have borrowed maximum number of books. Please deliver some first!");
                    }
                }
                  
            }
            else
            {
                MessageBox.Show("The book you have entered does not exists in the booklist!");
            }
           
        }


        // logging admin book add-remove-updates for security scenerio purposes
        public void LogWrite(string logMessage, string id, string bookid)
        {
            //string Path = "C:\\Users\\dyure\\source\\repos\\ProjectWithSql\\ProjectWithSql\\ProjectWithSql\\bin\\Debug";
            string Path = "C:\\Users\\civan\\Desktop";
            try
            {
                using (StreamWriter w = File.AppendText(Path + "\\" + "log.txt"))
                {
                    Log(logMessage, w,id,bookid);
                }
            }
            catch (Exception ex)
            {
            }
        }

        //back buttonfor guessts only
        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            WelcomePage wp = new WelcomePage();
            wp.Show();
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }
        // immediately filtering by bookname
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            DataView dv = new DataView(connection.getTable("BookList"));
            dv.RowFilter = string.Format("BookName LIKE '%{0}%'", textBox1.Text);
            dataGridView1.DataSource = dv;
        }
        // immediately filtering by author
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            DataView dv = new DataView(connection.getTable("BookList"));
            dv.RowFilter = string.Format("Author LIKE '%{0}%'", textBox2.Text);
            dataGridView1.DataSource = dv;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox2.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
        }

        public void Log(string logMessage, TextWriter txtWriter, string id, string bookid)
        {
            try
            {//setting inside of  the log file to make representation of  the log info clearer
                txtWriter.Write("\r\nLog Entry : ");
                txtWriter.WriteLine("{0} {1}", DateTime.Now.ToLongTimeString(),
                    DateTime.Now.ToLongDateString());
                
                txtWriter.WriteLine(" Admin " + id+"  :{0}", logMessage);
                txtWriter.WriteLine(" the book " + bookid);
               
                txtWriter.WriteLine("-------------------------------");
            }
            catch (Exception ex)
            {

            }
        }
        
    }
}
