﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ProjectWithSql
{
    public partial class LoginPage : Form
    {
        string desire; //login or signup
        string userid;
        public LoginPage(string desire)
        {
            this.desire = desire;
            InitializeComponent();
        }
        public LoginPage(string desire, string userid)
        {
            if (desire.Equals("changepw"))
            {
                this.userid = userid;
            }
            this.desire = desire;
            InitializeComponent();
        }
        
        DatabaseConnection connection = new DatabaseConnection();

        private void LoginPage_Load(object sender, EventArgs e)
        {
            groupBox1.Hide();
            groupBox2.Hide();
            groupBox3.Hide();
            groupBox4.Hide();
            label6.Hide();
            label7.Hide();

            if (desire.Equals("login"))
            {
                groupBox3.Show();
            }
            else if (desire.Equals("changepw"))
            {
                groupBox4.Location = new Point(groupBox3.Location.X, groupBox3.Location.Y);
                groupBox4.Show();
            }
            else
            {
                groupBox1.Show();
                groupBox1.Location = new Point(groupBox3.Location.X, groupBox3.Location.Y);
            }
           
        }

        //Login button
        private void button1_Click(object sender, EventArgs e)
        {
           
            if (connection.doesExist("UserList", textBox5.Text, "ID"))
            {
                User user = new User(textBox5.Text, textBox6.Text);
                if (textBox6.Text.Equals(user.getUserPW()))
                {
                    UserAccountView uav = new UserAccountView(user.getUserID(), user.getUserPW(), user.getBorrowList());
                    this.Close();
                    uav.Show();

                }
                else
                    MessageBox.Show("You password is incorrect!");
            }
           
            //checking that entered user id exists and entered pw matches with the id in the db
            else
                 MessageBox.Show("Invalid login informations. There is no such user exists!");
            
        }
            
        //signup button
        private void button2_Click(object sender, EventArgs e)
        {
            

            if (textBox1.Text.Length == 0 || textBox2.Text.Length == 0 || textBox3.Text.Length == 0 || textBox4.Text.Length == 0) //leaving any textbox blank warns user
                MessageBox.Show("Required areas cannot be blank!");

            else if (textBox2.Text != (textBox3.Text))
                MessageBox.Show("Passwords entered are not matching!");

            else if (connection.doesExist("UserList",textBox1.Text,"ID")==false) //if there is no matching user id already exists
            {
                connection.inserttoDatabase("UserList", textBox1.Text, textBox2.Text,textBox4.Text);
                MessageBox.Show("Succesful signup!");
                LoginPage login = new LoginPage("login");
                this.Close();
                login.Show();
                
            }

            else
                MessageBox.Show("This ID already has been taken!");
        }

        //back button
        private void button3_Click(object sender, EventArgs e)
        {
            WelcomePage wp = new WelcomePage();
            this.Close();
            wp.Show();
        }

        //forgot my pw button
        private void button4_Click(object sender, EventArgs e)
        {
            
            groupBox2.Show();
        }

        //submit secret q's answer
        private void button5_Click(object sender, EventArgs e)
        {

            if (connection.doesExist("UserList", textBox5.Text, "ID")) //if user exists
            {
                User user = new User(textBox5.Text);
                if (textBox7.Text.Equals(user.getUserSecretQ()))
                {
                    label6.Show();
                    label7.Show();
                    label7.Text = user.getUserPW();
                }
                else
                    MessageBox.Show("Secret question's answer is not matching!");
            }
            else
                MessageBox.Show("Entered user does not exist. Please check your user id!");
            
        }

        //submit new pw
        private void button6_Click(object sender, EventArgs e)
        {
            User user = new User(userid);
            if (textBox8.Text != user.getUserPW())//old pw is not matching
            {
                MessageBox.Show("Old password is not matching!");
            }
            else if (textBox9.Text.Equals(textBox10.Text))
            {
                user.setUserPW(textBox9.Text);
                MessageBox.Show("Succesfully changed your password!");
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                groupBox2.Hide();
                this.Close();
                UserAccountView ua = new UserAccountView(userid, user.getUserPW());
                ua.Show();
            }
            else
                MessageBox.Show("New passwords are not matching!");
        }
    }
}
