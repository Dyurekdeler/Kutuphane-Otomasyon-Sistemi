﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectWithSql
{
    public partial class UserAccountView : Form
    {
        string id, pw;
        string[] borrowlist;
        public UserAccountView(string id, string pw, string[] borrowlist)
        {
            InitializeComponent();
            this.id = id;
            this.pw = pw;
            this.borrowlist = borrowlist;
        }
        public UserAccountView(string id, string pw)
        {
            User user = new User(id);
            InitializeComponent();
            this.id = id;
            this.pw = pw;
            borrowlist = user.getBorrowList();
        }
        
        DatabaseConnection connection = new DatabaseConnection();

        private void UserAccountView_Load(object sender, EventArgs e)
        {
            User user = new User(id, pw);
            if (user.getUserLvl().Equals("1"))
            {
                label5.Text = "Welcome Admin : " + user.getUserID();
            }
            else
            {
                label5.Text = "Welcome User : " + user.getUserID();
                button5.Hide();
                
            }
            label2.Hide();
            label1.Text = "You have borrowed " + user.getUserBookNum() + " books.";
            //showing the firsttime 
            ShowBorrowList();
            RefreshBorrowList();
            fillHistoryList();
        }

        public void ShowBorrowList()
        {
            User user = new User(id, pw);
            string[] temparray = user.getBorrowList();
            for (int i = 0; i < 5; i++)
            {
                if (temparray[i].Equals("0"))
                {
                    dataGridView1.Rows.Add("-");
                }
                else
                    dataGridView1.Rows.Add(temparray[i]);

            }
        }


        //logout button
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            WelcomePage wp = new WelcomePage();
            wp.Show();
        }


        //show borrowlist
        private void button2_Click(object sender, EventArgs e)
        {
            User user = new User(id, pw);
            RefreshBorrowList();
            label1.Text = "You have borrowed " + user.getUserBookNum() + " books.";
            fillHistoryList();
        }

        //go to booklist
        private void button4_Click(object sender, EventArgs e)
        {
            User user = new User(id, pw);
            if (string.Equals(user.getUserLvl(), "0"))  //assuming there would be only 0 or 1 inputted to Lvl field in the db
            {
                
                BookListView books = new BookListView(user.getUserID(), user.getUserPW());//load books form with user feautures
                this.Close();
                books.Show();
            }
            else            
            {
                
                BookListView books = new BookListView(user.getUserID(), user.getUserPW());//load books form with admin feautures
                this.Close();
                books.Show();
            }
        }

       
        // change pw button
        private void button1_Click(object sender, EventArgs e)
        {
            LoginPage lp = new LoginPage("changepw",id);
            this.Hide();
            lp.Show();
            
        }

       

        public void RefreshBorrowList() //this method prevents the datagridview to load the same data to down of the existing
        {
            User user = new User(id, pw);
            string[] temp = user.getBorrowList();
            for (int i = 0; i < 5; i++)
            {
                if (temp[i].Equals("0"))
                {
                    dataGridView1.Rows[i].Cells[0].Value = "-";
                }
                else
                {
                    dataGridView1.Rows[i].Cells[0].Value = temp[i];
                }
                        
                        Book book = new Book(temp[i]);
                        dataGridView1.Rows[i].Cells[1].Value = (book.getBookName());
                    
            }         
            
        }
        //refresh button
        private void button2_Click_1(object sender, EventArgs e)
        {
            RefreshBorrowList();
        }
        //show manual
        int manualclick = 0;
        

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (manualclick % 2 == 0)
            {
                label2.Show();
                listBox1.Hide();
                button5.Text = "Hide Manual";
                groupBox3.Text = "Manual";
            }
            else
            {
                button5.Text = "Show Manual";
                label2.Hide();
                listBox1.Show();
                groupBox3.Text = "History";
            }
            manualclick++;
        }

        void fillHistoryList()
        {
            User user = new User(id, pw);
            
            ArrayList temp = user.getHistory();
            foreach(string a in temp)
            {
                if (listBox1.Items.Equals(a.ToString()))
                {
                    //do nothing
                }
                else
                {
                    listBox1.Items.Add(a.ToString());
                }
                
              
            }
        }
    }
}
