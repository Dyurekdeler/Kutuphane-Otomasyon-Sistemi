﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectWithSql
{
    public partial class WelcomePage : Form
    {
        public WelcomePage()
        {
            InitializeComponent();
        }

        //initializing a ticker to show time
        private void WelcomePage_Load(object sender, EventArgs e)
        {
            Timer timer = new Timer();
            label5.Hide();
            label6.Hide();
            timer.Interval = 1000;
            timer.Tick += new EventHandler(this.timer1_Tick);
            timer.Start();
            getTicker();
            getDate();

        }

        //loads login form
        private void button1_Click(object sender, EventArgs e)
        {
            LoginPage loginpage = new LoginPage("login");
            this.Hide();
            loginpage.Show();
        }

        //loads uneditable booklist
        private void button2_Click(object sender, EventArgs e)
        {
            //via this button nobody can change the booklist but view and search in it
            BookListView books = new BookListView("guest");
            this.Hide();
            books.Show();
        }

        //loads signup form ( actually it is login form with some .Hide() feautures )
        private void button3_Click(object sender, EventArgs e)
        {
            LoginPage loginpage = new LoginPage("signup");
            this.Hide();
            loginpage.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            getTicker();
        }

        public void getTicker()
        {
            label5.Show();
            int h = DateTime.Now.Hour;
            int m = DateTime.Now.Minute;
            int s = DateTime.Now.Second;
            string holder = h.ToString() + ":" + m.ToString() + ":" + s.ToString();
            label5.Text = holder;
        }
        public void getDate()
        {
            label6.Show();
            DateTime d = DateTime.Today;
            label6.Text = d.ToShortDateString();
        }
    }
}
