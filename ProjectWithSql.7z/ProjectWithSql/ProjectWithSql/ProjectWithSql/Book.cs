﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectWithSql
{
    public class Book
    {
        string name,author,id;

        public Book(string name, string author, string id)
        {
            this.name = name;
            this.author = author;
            this.id = id;
        }

        public Book(string id)
        {
            name = getBookName();
            author = getAuthor();
            this.id = id;

        }
        public Book(string name, string author)
        {
            this.name = name;
            this.author = author;
            id = getID();
        }
        
        
        DatabaseConnection connection = new DatabaseConnection();

        public string getBookName()
        {
            string holder = ""; //initialize null for the first time for unfound
            if (connection.doesExist("BookList", id, "ID"))
            {
                holder = connection.getTable("BookList", id, "ID").Rows[0][1].ToString();
            }
            return holder;
        }
        public string getID()
        {
            string holder = ""; //initialize null for the first time for unfound
            if (connection.doesExist("BookList", name, "BookName"))
            {
                holder = connection.getTable("BookList", name, "BookName").Rows[0][0].ToString();
            }
            return holder;
        }
        public int getQuantity()
        {
            int holder = 0; //initialize null for the first time unfound userid
            if (connection.doesExist("BookList", id, "ID"))
            {
                holder = Convert.ToInt32(connection.getTable("BookList", id, "ID").Rows[0][3]);
            }
            return holder;
        }
        public string getAuthor()
        {
            string holder = ""; //initialize null for the first time unfound userid
            if (connection.doesExist("BookList", author, "Author"))
            {
                holder = connection.getTable("BookList", author, "Author").Rows[0][2].ToString();
            }
            return holder;
        }

        //all the sets are handled by ID except setID does not exists for security purposes
        public void setBookName(string value)
        {
            if (connection.doesExist("BookList", id, "ID") && value.Length>0)
            {
                connection.Update("BookList", value, "BookName", id);
            }

        }

        public void setQuantity(int value)
        {
            if (connection.doesExist("BookList", id, "ID") && value>= 0)
            {
                connection.Update("BookList", value.ToString(), "Quantity", id);
            }

        }

        public void setAuthor(string value )
        {
            if (connection.doesExist("BookList", id, "ID") && value.Length>0)
            {
                connection.Update("BookList", value, "Author", id);
            }

        }
        
    }

}
