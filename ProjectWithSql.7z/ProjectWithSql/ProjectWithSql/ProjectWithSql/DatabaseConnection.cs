﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectWithSql
{
    public class DatabaseConnection //database processes are handled in this class
    {
        // deniz pc SqlConnection con = new SqlConnection("Data Source=DENSY-DESKTOP\\MSSQLSERVER01;Initial Catalog=ListsForLibrary;Integrated Security=True");
        SqlConnection con = new SqlConnection("Data Source = TESLA-LAPTOP; Initial Catalog = ListsForLibrary; Integrated Security = True");
        // civan pc SqlConnection con = new SqlConnection("Data Source=DESKTOP-7FPARHJ\\SQLEXPRESS;Initial Catalog=ListsForLibrary;Integrated Security=True");
        public SqlConnection getConnection()
        {
            return con;
        }

        //returns the specified row of the db
        public DataTable getTable(string table, string value, string field)
        {
            if (table.Equals("UserList")) //returns found user information
            {
                getConnection().Open();
                SqlCommand cmd = new SqlCommand("select ID,PW,Lvl,BookNumber,Book0,Book1,Book2,Book3,Book4,SecretQ,History from UserList where " + field + "=" + "'" + value + "'", getConnection());
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                getConnection().Close();
                return dt;
            }
            else if (table.Equals("BookList"))//returns found book information
            {
                getConnection().Open();
                SqlCommand cmd = new SqlCommand("select ID,BookName,Author,Quantity from BookList where " + field + "=" + "'" + value + "'", getConnection());
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                getConnection().Close();
                return dt;
            }
            else //anything except BookList or UserList returns null
                throw new NotSupportedException();
        }

        //polymorphic getTable for printing all the database to datagridviews
        public DataTable getTable(string table)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM " + table, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            return dt;
        }

        //insert                                   userid            userpw 
        public void inserttoDatabase(string table, string id, string pw, string answer)
        {
            if (table.Equals("UserList"))  //adding a user to userlist
            {
                getConnection().Open();
                SqlCommand cmd = new SqlCommand("insert into UserList (ID,PW,Lvl,BookNumber,Book0,Book1,Book2,Book3,Book4,SecretQ,History)values (@userid,@userpw,@userlvl,@booknumber,@book0,@book1,@book2,@book3,@book4,@secretq,@history)", getConnection());
                cmd.Parameters.AddWithValue("@userid", id);
                cmd.Parameters.AddWithValue("@userpw", pw);
                cmd.Parameters.AddWithValue("@userlvl", "0"); // nobody can sign up as admin
                cmd.Parameters.AddWithValue("@booknumber", 0); // at the start borrow books are 0
                cmd.Parameters.AddWithValue("@book0", 0); // at the start borrowlist is empty
                cmd.Parameters.AddWithValue("@book1", 0);
                cmd.Parameters.AddWithValue("@book2", 0);
                cmd.Parameters.AddWithValue("@book3", 0);
                cmd.Parameters.AddWithValue("@book4", 0);
                cmd.Parameters.AddWithValue("@secretq", answer);
                cmd.Parameters.AddWithValue("@history", "");
                cmd.ExecuteNonQuery();
                getConnection().Close();
            }

            else //when any unrecognized tables are given
                throw new NotSupportedException();
        }

        //polymorphic insert  with more parameters       bookname        author          id
        public void inserttoDatabase(string table, string field1, string field2, string field3,string quantity)
        {
            if (table.Equals("BookList"))
            {
                Book book = new Book(field1, field2, field3);
                getConnection().Open();
                SqlCommand cmd = new SqlCommand("insert into BookList (ID,BookName,Author,Quantity)values (@id,@bookname,@author,@quantity)", getConnection());
                cmd.Parameters.AddWithValue("@id", field3);
                cmd.Parameters.AddWithValue("@bookname", field1);
                cmd.Parameters.AddWithValue("@author", field2);
                cmd.Parameters.AddWithValue("@quantity", quantity);
                cmd.ExecuteNonQuery();
                getConnection().Close();

            }
            else //when any unrecognized tables are given
                throw new NotSupportedException();
        }
    
        //delete by id
        public void deletefromDatabase(string table, string value)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete From " + table + " where ID="+"'"+value+"'", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        
        //search by any field and corresponding value
        public bool doesExist(string table, string value ,string field)
        {
           if (getTable(table, value ,field).Rows.Count > 0) //if search is succesful
                    return true;
           else
                    return false;
        }

        //update by id
        public void Update(string table, string newvalue,string changingfield,string id)
        {
                getConnection().Open();
                SqlCommand cmd = new SqlCommand("UPDATE "+table+" SET " + changingfield + "=" + "'" + newvalue + "'" + " WHERE ID= " + "'" + id + "'", getConnection());
                //cmd.Parameters.AddWithValue(changingfield, newvalue);
                cmd.ExecuteNonQuery();
                getConnection().Close();
        }
    }
}
