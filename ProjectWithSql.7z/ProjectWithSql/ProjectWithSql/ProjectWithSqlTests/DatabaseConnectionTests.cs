﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProjectWithSql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectWithSql.Tests
{
    [TestClass()]
    public class DatabaseConnectionTests
    {
        [TestMethod()]
        public void doesExistTest()
        {
            DatabaseConnection d = new DatabaseConnection();
            bool check = d.doesExist("UserList", "den", "ID");
            Assert.IsTrue(check);
        }
        
    }
}