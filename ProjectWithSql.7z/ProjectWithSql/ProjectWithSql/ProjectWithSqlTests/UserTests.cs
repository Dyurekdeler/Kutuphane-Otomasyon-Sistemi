﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProjectWithSql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectWithSql.Tests
{
    [TestClass()]
    public class UserTests
    {
        [TestMethod()]
        public void getUserLvlTest()
        {// den 123 already exists as an admin
            User u = new User("den", "123");
            string check = u.getUserLvl();
            Assert.AreEqual(check, "1");
        }

        [TestMethod()]
        public void canborrowbookTest()
        {
            int a=7;
            User u = new User("den","123");
            u.setUserBookNum(a);
            bool check=u.canborrowbook();
            Assert.IsFalse(check);
        }
    }
}